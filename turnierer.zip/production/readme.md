# Turnierer - Turniere einfach managen. 

## Installation

```
composer install
php artisan migrate
npm install --global gulp-cli
npm install
gulp
php artisan serve
```

## Screenshots

![group](https://raw.githubusercontent.com/bslinz2/turnierer/master/screenshots/tournaments.png "Turniere")

![group](https://raw.githubusercontent.com/bslinz2/turnierer/master/screenshots/tournament.png "Turnier")

![group](https://raw.githubusercontent.com/bslinz2/turnierer/master/screenshots/group-0.png "Gruppe 1")

![group](https://raw.githubusercontent.com/bslinz2/turnierer/master/screenshots/group-1.png "Gruppe 2")
